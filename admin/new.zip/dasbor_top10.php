<?php
// get the HTML
require_once(dirname(__FILE__).'../../assets/html2pdf/html2pdf.class.php'); 
ob_start();
session_start();
include 'config.php';
$concet=opendtcek(); 
$kd_toko=$_SESSION['id_toko'];     
if($_POST['pilihbulan']=='1'){
    $ktbln  = 'Januari';  
}
if($_POST['pilihbulan']=='2'){
    $ktbln  = 'Februari';  
}
if($_POST['pilihbulan']=='3'){
    $ktbln  = 'Maret';  
}
if($_POST['pilihbulan']=='4'){
    $ktbln  = 'April';  
}
if($_POST['pilihbulan']=='5'){
    $ktbln  = 'Mei';  
}
if($_POST['pilihbulan']=='6'){
    $ktbln  = 'Juni';  
}
if($_POST['pilihbulan']=='7'){
    $ktbln  = 'Juli';  
}
if($_POST['pilihbulan']=='8'){
    $ktbln  = 'Agustus';  
}
if($_POST['pilihbulan']=='9'){
    $ktbln  = 'September';  
}
if($_POST['pilihbulan']=='10'){
    $ktbln  = 'Oktober';  
}
if($_POST['pilihbulan']=='11'){
    $ktbln  = 'Nopember';  
} 
if($_POST['pilihbulan']=='12'){
    $ktbln  = 'Desember';  
}
if($_POST['ctkpil']=='0'){
   $pil=''; 
   $nmpil='(SEMUA BAGIAN)';
}else{
   $pil=' AND dum_jual.id_bag='.$_POST['ctkpil']; 
   $ss=$_POST['ctkpil'];
   $dd=mysqli_query($concet,"SELECT nm_bag FROM bag_brg WHERE no_urut='$ss'");
   $qq=mysqli_fetch_assoc($dd);
   $nmpil='('.$qq['nm_bag'].')';
   mysqli_free_result($dd);unset($qq);
}

$endyear = $_POST['pilihtahun'];
$endbln = $_POST['pilihbulan'];
$cq=mysqli_query($concet,"SELECT * FROM toko WHERE kd_toko='$kd_toko'");
$dtt=mysqli_fetch_assoc($cq);
$nm_toko=$dtt['nm_toko'];  
mysqli_free_result($cq);unset($dtt);

?>
<style>  
    th
    {
        text-align: center;
        border: solid 1px #113300;
        padding:5px;
        /*background: #EEFFEE;*/
    }

    td
    {
        border: solid 1px #113300;
        background: white;
        font-size: 9pt;
        border-left: none;
        border-right: none;
        border-top: none;
        border-style:dotted; 
    }

</style>

<page backtop="10mm" backbottom="10mm" backleft="5mm" backright="5mm">
  <h5 style="text-align: left;font-size: 8pt;margin-bottom:5px ">BEST SELLER TOKO FAFA <?='BULAN '.strtoupper($ktbln).'  TAHUN '.$endyear.' '.$nmpil ?></h5>
  <table cellspacing="0" style="width: 100%; border: solid 1px black; text-align: center; font-size: 8pt;">
    <thead >
        <tr>
        <th style="width:5%;">NO</th>
        <th >NAMA BARANG</th>
        <th style="width:15%">TRANSAKSI</th>
        <th style="width:10%">STOK</th>
        <th style="width:15%">RANGKING</th>
      </tr> 
    </thead>   
      <?php 
      $cek=mysqli_query($concet,"SELECT dum_jual.kd_brg,dum_jual.nm_brg,count(nm_brg) as jmlbrg FROM dum_jual 
      WHERE month(dum_jual.tgl_jual)='$endbln' AND year(dum_jual.tgl_jual)='$endyear' AND INSTR(dum_jual.nm_brg,'JASA')=0 $pil
      GROUP BY dum_jual.nm_brg ORDER BY COUNT(*) DESC LIMIT 200");
      $a=0;
      while($data=mysqli_fetch_array($cek)){
        $kdbrg=$data['kd_brg'];
        $a++; $stok=0;
        $c=mysqli_query($concet,"SELECT sum(stok_jual) as jmls FROM beli_brg WHERE kd_brg='$kdbrg'");
        $d=mysqli_fetch_assoc($c);
        $stok=round($d['jmls'],0);
        
        $ex=explode(";",carisatkecil2($kdbrg,$concet));
        $sat=strtolower(ceknmkem_2($ex[0],$concet));
        unset($c,$d,$ex); ?>
        <tr style="font-size: 10pt">
          <td align="right"><?=$a?>.</td>
          <td><?=$data['nm_brg']?></td>
          <td style="text-align:center"><?=$data['jmlbrg']?>&nbsp;kali</td>
          <td style="text-align:center"><?=$stok.' '.$sat?></td>
          <td style="text-align: center"><i class="fa fa-star" style="color: orange"></i> <?=$a?></td> 
        </tr>
        <?php  
      }  
      ?> 
  </table>
</page>

<?php
    unset($data,$cek);
    mysqli_close($concet);
    $c_nmfile='bestseller.pdf'; 
    $content = ob_get_clean();

    try
    {
        $html2pdf = new HTML2PDF('P', 'A4', 'en' );
        $html2pdf->pdf->SetDisplayMode('fullpage');
        $html2pdf->writeHTML($content, isset($_GET['vuehtml']));
        $html2pdf->Output($c_nmfile);
    }
    catch(HTML2PDF_exception $e) {
      echo $e;
      exit;
    }
?>