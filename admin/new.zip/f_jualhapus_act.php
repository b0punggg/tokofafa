<?php 
  ob_start();
   include "config.php";
   session_start();
   
   $conhps     = opendtcek();
   date_default_timezone_set('Asia/Jakarta');
   $tghi       = date("Y-m-d H:i:s");
   $id_user    = $_SESSION['id_user'];
   $kd_toko    = $_SESSION['id_toko'];
   $nm_user    = $_SESSION['nm_user'];
   $oto        = $_SESSION['kodepemakai']; 
   $tglhr      = date('Y-m-d');
   $id         = $_POST['id'];
   $qty_brg    = $kd_sat=0;$kd_brg='';

   $cek        = mysqli_query($conhps,"SELECT * FROM dum_jual where no_urut='$id'");
   $data       = mysqli_fetch_array($cek);
   $qty_brg    = $data['qty_brg'];
   $kd_sat     = $data['kd_sat'];
   $kd_brg     = mysqli_escape_string($conhps,trim($data['kd_brg']));
   $no_item    = $data['no_item'];
   $bayar      = $data['bayar'];
   $no_fakjual = mysqli_escape_string($conhps,$data['no_fakjual']);
   $tgl_jual   = mysqli_escape_string($conhps,$data['tgl_jual']);
   $jml_brg    = konjumbrg2($kd_sat,$kd_brg,$conhps)*$qty_brg;
   unset($cek,$data);

   //**cek jika potong stok atau tidak
    $q      = mysqli_query($conhps,"SELECT * FROM seting WHERE nm_per='POTONG'");
    $d      = mysqli_fetch_assoc($q);
    $potong = $d['kode'];
    mysqli_free_result($q);unset($d);
   
   $cek     = mysqli_query($conhps,"SELECT brg_klr,jml_brg FROM mas_brg where kd_brg='$kd_brg'");
   $data    = mysqli_fetch_array($cek);
   $brg_klr = $data['brg_klr'];
   $jumbrg  = $data['jml_brg'];
   unset($data);mysqli_free_result($cek);

   $brg_klr=$brg_klr-$jml_brg;
   if ($brg_klr<0){
    $brg_klr=0;
    $jumbrg=0;
   }
   $jumbrg=$jumbrg+$jml_brg;
    
   $cek        = mysqli_query($conhps,"SELECT stok_jual FROM beli_brg where no_urut='$no_item'");
   $data       = mysqli_fetch_array($cek);
   $jual_stok  = $data['stok_jual'];
   $jual_stok  = $jual_stok+$jml_brg;
   unset($data);mysqli_free_result($cek);
  
  if($kd_toko!="IDTOKO-2"){ 

    if ($potong==1){
      $conhps2=opendtcek(); 
      $xf=mysqli_query($conhps2, "UPDATE beli_brg set stok_jual='$jual_stok' WHERE no_urut='$no_item' ");  
      $f=mysqli_query($conhps2, "UPDATE mas_brg SET brg_klr='$brg_klr',jml_brg='$jumbrg' WHERE kd_brg='$kd_brg'");
    }
    $f=mysqli_query($conhps2, "DELETE from dum_jual WHERE no_urut='$id'" );
    mysqli_close($conhps2);
    
    //cek pd mas_jual 
    $ada=0;
    $cari=mysqli_query($conhps,"SELECT * FROM dum_jual where no_fakjual='$no_fakjual' and tgl_jual='$tgl_jual' AND kd_toko='$kd_toko' ");
    if(mysqli_num_rows($cari)>=1){
      $ada=1;
    }else{
      $ada=0;
      mysqli_query($conhps,"DELETE FROM mas_jual WHERE no_fakjual='$no_fakjual' and tgl_jual='$tgl_jual' AND kd_toko='$kd_toko'");
      mysqli_query($conhps,"DELETE FROM mas_jual_hutang WHERE no_fakjual='$no_fakjual' and tgl_jual='$tgl_jual' AND kd_toko='$kd_toko'");
    }
    unset($cari);

    if($f){
      if($ada==1){
        ?><script>
        popnew_warning("Data terhapus, silahkan update bayar nota");
        document.getElementById("edit-warning").value=0;
        kosongkan();
        caribrgjual(1,true);
        </script><?php  
      }else{ 
        ?><script>
        popnew_warning("Data telah terhapus...");
        document.getElementById("edit-warning").value=0;
        kosongkan();
        caribrgjual(1,true);
        </script><?php  
      }
    }else {
      ?><script>popnew_warning("Data gagal dihapus..");
      document.getElementById("edit-warning").value=0;
      kosongkan();
      caribrgjual(1,true);
      </script><?php  
    }
  }else{
    if($oto=='2'){
      if ($potong==1){
        $conhps2=opendtcek(); 
        $xf=mysqli_query($conhps2, "UPDATE beli_brg set stok_jual='$jual_stok' WHERE no_urut='$no_item' ");  
        $f=mysqli_query($conhps2, "UPDATE mas_brg SET brg_klr='$brg_klr',jml_brg='$jumbrg' WHERE kd_brg='$kd_brg'");
      }
      $f=mysqli_query($conhps2, "DELETE from dum_jual WHERE no_urut='$id'" );
      mysqli_close($conhps2);
      
      //cek pd mas_jual 
      $ada=0;
      $cari=mysqli_query($conhps,"SELECT * FROM dum_jual where no_fakjual='$no_fakjual' and tgl_jual='$tgl_jual' AND kd_toko='$kd_toko' ");
      if(mysqli_num_rows($cari)>=1){
        $ada=1;
      }else{
        $ada=0;
        mysqli_query($conhps,"DELETE FROM mas_jual WHERE no_fakjual='$no_fakjual' and tgl_jual='$tgl_jual' AND kd_toko='$kd_toko'");
        mysqli_query($conhps,"DELETE FROM mas_jual_hutang WHERE no_fakjual='$no_fakjual' and tgl_jual='$tgl_jual' AND kd_toko='$kd_toko'");
      }
      unset($cari);

      if($f){
        if($ada==1){
          ?><script>
          popnew_warning("Data terhapus, silahkan update bayar nota");
          document.getElementById("edit-warning").value=0;
          kosongkan();
          caribrgjual(1,true);
          </script><?php  
        }else{ 
          ?><script>
          popnew_warning("Data telah terhapus...");
          document.getElementById("edit-warning").value=0;
          kosongkan();
          caribrgjual(1,true);
          </script><?php  
        }
      }else {
        ?><script>popnew_warning("Data gagal dihapus..");
        document.getElementById("edit-warning").value=0;
        kosongkan();
        caribrgjual(1,true);
      </script><?php  
      }
    }else{
      //log file
      ?><script>if(confirm('Transaksi Hapus Per Item tidak dapat dilakukan, klik Oke untuk kirim permintaan ke Admin')){
        del_oto_i('<?=$id?>');     
      }</script><?php
      
    }
  }
 ?>    

<?php
  mysqli_close($conhps);
  $html = ob_get_contents(); 
  ob_end_clean();
  echo json_encode(array('hasil'=>$html));
?>